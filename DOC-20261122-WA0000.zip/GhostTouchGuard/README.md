# GhostTouchGuard (Android / Kotlin)

A native Android Studio Kotlin application built to detect and suppress **ghost touches** (phantom/unwanted multi-touch events) on the **Xiaomi 13 5G** running **HyperOS / Android 14 (API 34)**.

- **Package**: `com.ghosttouchguard.app`
- **Min SDK**: `26` (Android 8.0)
- **Target / Compile SDK**: `34` (Android 14)
- **Dependencies**: Pure AndroidX only (`core-ktx`, `appcompat`, `constraintlayout`, `cardview`) — no third-party libraries, no root required.

---

## Project Structure

```text
GhostTouchGuard/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── README.md
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/ghosttouchguard/app/
        │   ├── MainActivity.kt               # Permission setup, controls, settings, live status, test pad
        │   ├── FloatingService.kt            # Foreground service, draggable floating toggle, lock/wake cycle
        │   ├── GhostMonitorView.kt           # Full-screen transparent overlay, 800ms touch block, 6s cooldown
        │   ├── GhostDeviceAdminReceiver.kt   # DeviceAdminReceiver for DevicePolicyManager.lockNow()
        │   └── GuardPreferences.kt           # SharedPreferences config, floating coordinates, event counters
        └── res/
            ├── drawable/                     # Shield icon, red/grey floating circles, card & banner shapes
            ├── layout/
            │   ├── activity_main.xml
            │   ├── floating_button_layout.xml
            │   └── ghost_monitor_overlay.xml
            ├── mipmap-anydpi-v26/            # Adaptive launcher icons
            ├── values/
            │   ├── colors.xml
            │   ├── strings.xml
            │   └── themes.xml
            └── xml/
                └── device_admin_policies.xml # Declares <force-lock /> policy
```

---

## How Protection Works

1. **Floating Button Control (`FloatingService`)**
   - Displays a small, draggable circular button on top of all apps (`TYPE_APPLICATION_OVERLAY`).
   - Tapping toggles protection **ON** (red) / **OFF** (grey); dragging repositions it and persists coordinates.
   - Runs inside a `specialUse` foreground service with a persistent low-priority notification and quick Toggle action.

2. **Ghost Touch Detection (`GhostMonitorView`)**
   - Attaches a full-screen transparent overlay behind the floating button.
   - Normally stays in pass-through mode (`FLAG_NOT_TOUCHABLE | FLAG_WATCH_OUTSIDE_TOUCH`) so normal single-finger taps and scrolling pass straight through to the app underneath.
   - Triggers when **2 or more simultaneous touches** are detected (configurable from 2 to 5) or when a rapid phantom-touch burst triggers a brief 140 ms pointer-count verification probe.

3. **Software Digitizer Reset (~800 ms)**
   - Immediately removes `FLAG_NOT_TOUCHABLE` so the overlay intercepts and consumes **all** touch input (`onTouchEvent` / `dispatchTouchEvent` returns `true`) for **800 ms**.
   - Triggers a 65 ms haptic vibration pulse and shows the **"Resetting touch…"** HUD banner.
   - After 800 ms, clears the banner and resumes normal touch pass-through.

4. **Lock & Wake Escalation + 6-Second Cooldown**
   - After the 800 ms reset finishes, `GhostMonitorView` monitors a post-reset persistence window (default **2.0 seconds**, adjustable `1.0 s – 5.0 s`).
   - If ghost touches keep arriving through the persistence threshold, `FloatingService` locks the screen via `DevicePolicyManager.lockNow()`.
   - After the configured wake delay (default **1.0 second**, adjustable `0.5 s – 3.0 s`), it wakes the display using a timed `PowerManager` `WakeLock` (`ACQUIRE_CAUSES_WAKEUP`) and checks `KeyguardManager`.
   - Enters a mandatory **6-second cooldown** immediately after the lock-wake cycle so it cannot get stuck in a lock loop.

---

## How to Open, Build & Install on Xiaomi 13 5G

### 1. Open in Android Studio
1. Launch **Android Studio** (Jellyfish / Koala or newer, with JDK 17).
2. Click **File > Open** and select this project root folder (`GhostTouchGuard`).
3. Wait for Gradle sync to finish (requires Android SDK Platform 34 and Build-Tools 34.x).

### 2. Enable USB Debugging on Xiaomi 13 5G
1. Open **Settings > About phone** and tap **OS version** (HyperOS version) 7 times until Developer Options are enabled.
2. Go to **Settings > Additional settings > Developer options**:
   - Enable **USB debugging**.
   - Enable **Install via USB** (Xiaomi requires this to push APKs from Android Studio/ADB).
3. Connect the Xiaomi 13 5G via USB cable and accept the RSA debugging prompt on the phone.

### 3. Build & Install
- **Via Android Studio**: Select your Xiaomi 13 5G device in the toolbar and press **Run (`Shift+F10`)**.
- **Via Gradle CLI**:
  ```bash
  ./gradlew assembleDebug
  adb install -r app/build/outputs/apk/debug/app-debug.apk
  ```

---

## First-Time Setup & Permission Order

Open **GhostTouchGuard** on your Xiaomi 13 5G and grant permissions **in order**:

1. **(a) Draw Over Other Apps (`SYSTEM_ALERT_WINDOW`)** — Tap **Grant**, find **GhostTouchGuard**, and enable *Allow display over other apps*.
2. **(b) Device Admin (Screen Lock)** — Tap **Grant** and confirm **Activate this device admin app** (required for `DevicePolicyManager.lockNow()`).
3. **(c) Notifications (Android 13+)** — Tap **Grant** and allow notifications so the foreground service stays alive.
4. **(d) Foreground Service Permission** — Declared automatically in `AndroidManifest.xml` (`FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_SPECIAL_USE`).

> Protection cannot be armed until both **(a) Draw Over Other Apps** and **(b) Device Admin** are granted.

Once granted, tap **Show Floating Button** and toggle protection ON (floating button turns **Red**). You can test the 800 ms reset and 2-second lock/wake escalation directly using the **Touch Monitor Test Pad** in `MainActivity`.

---

## Required Xiaomi 13 5G / HyperOS Settings

HyperOS aggressively kills background services and blocks overlays spawned from background services unless these three settings are enabled:

1. **Settings > Apps > Manage apps > GhostTouchGuard > Autostart**: **ON**
2. **Battery saver**: **No restrictions** (under *App battery saver*)
3. **Other permissions > "Display pop-up windows while running in background"**: **Allow** (essential for the floating overlay to remain active across apps)

You can jump straight to the app's HyperOS settings page using the **Open App Settings (HyperOS)** button inside the app.

---

## Honest Technical & Hardware Limits

- **No root = no hardware digitizer reset**: Standard non-rooted Android apps cannot reset the Synaptics/Goodix touchscreen IC firmware or clear kernel input buffers directly. The 800 ms reset is the closest software equivalent: blocking and draining touch events at the Android `WindowManager` overlay layer, plus triggering a display lock/wake cycle if touches persist.
- **Pass-through multi-touch privacy rules (Android 12–14)**: Android's `InputDispatcher` blocks `FLAG_NOT_TOUCHABLE` overlays from reading raw multi-touch coordinates of touches sent to *other* apps (`ACTION_OUTSIDE` only reports down notifications). `GhostMonitorView` handles this using rapid `ACTION_OUTSIDE` burst detection + a brief 140 ms pointer-count verification probe, plus direct multi-touch inspection during active windows and the in-app Test Pad.
- **Wake does not bypass your lock screen**: `PowerManager` + `KeyguardManager` only wakes the screen back up after `lockNow()`. If you use a PIN, pattern, or fingerprint, Android's lock screen remains enforced — no non-system app can bypass it.
- **Hardware damage cannot be fixed in software**: If ghost touches are caused by a cracked/delaminating OLED digitizer, static/grounding noise from a faulty third-party charger, a damaged screen protector, or moisture under the glass, no app can cure the underlying hardware fault.
