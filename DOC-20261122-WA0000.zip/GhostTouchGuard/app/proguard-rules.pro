# Add project specific ProGuard rules here.
-keep class com.ghosttouchguard.app.GhostDeviceAdminReceiver { *; }
