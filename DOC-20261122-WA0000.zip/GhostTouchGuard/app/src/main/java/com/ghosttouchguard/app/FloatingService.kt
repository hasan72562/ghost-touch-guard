package com.ghosttouchguard.app

import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.abs

class FloatingService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: GuardPreferences
    private lateinit var devicePolicyManager: DevicePolicyManager
    private lateinit var powerManager: PowerManager
    private lateinit var keyguardManager: KeyguardManager

    private val handler = Handler(Looper.getMainLooper())

    private var ghostMonitorView: GhostMonitorView? = null
    private var floatingView: View? = null
    private var floatingLayoutParams: WindowManager.LayoutParams? = null

    private var floatingCircle: LinearLayout? = null
    private var floatingStateText: TextView? = null

    private val wakeRunnable = Runnable { wakeScreen() }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = GuardPreferences(this)
        devicePolicyManager =
            getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager

        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!hasMandatoryPermissions()) {
            prefs.isProtectionEnabled = false
            prefs.isServiceRunning = false
            prefs.guardStateLabel = "OFF"
            Toast.makeText(
                this,
                "Grant Overlay + Device Admin permissions first.",
                Toast.LENGTH_SHORT
            ).show()
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForegroundService()
        ensureOverlaysAttached()

        when (intent?.action) {
            ACTION_TOGGLE_PROTECTION -> {
                setProtectionArmed(!prefs.isProtectionEnabled)
            }
            ACTION_SET_PROTECTION -> {
                val armed = intent.getBooleanExtra(EXTRA_ARMED, false)
                setProtectionArmed(armed)
            }
            ACTION_REPORT_POINTER_SAMPLE -> {
                val count = intent.getIntExtra(EXTRA_POINTER_COUNT, 0)
                ghostMonitorView?.handlePointerSample(count)
            }
            ACTION_STOP_SERVICE -> {
                setProtectionArmed(false)
                prefs.isServiceRunning = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                setProtectionArmed(prefs.isProtectionEnabled)
            }
        }

        prefs.isServiceRunning = true
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(wakeRunnable)
        detachOverlays()
        prefs.isServiceRunning = false
        if (!prefs.isProtectionEnabled) {
            prefs.guardStateLabel = "OFF"
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun hasMandatoryPermissions(): Boolean {
        val canOverlay = Settings.canDrawOverlays(this)
        val adminActive =
            devicePolicyManager.isAdminActive(GhostDeviceAdminReceiver.getComponentName(this))
        return canOverlay && adminActive
    }

    private fun startAsForegroundService() {
        val notification = buildNotification(prefs.isProtectionEnabled)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun ensureOverlaysAttached() {
        if (ghostMonitorView == null) {
            val monitor = GhostMonitorView(
                context = this,
                windowManager = windowManager,
                prefs = prefs,
                onPersistenceEscalation = { performLockAndWakeCycle() }
            )
            windowManager.addView(monitor, monitor.overlayLayoutParams)
            ghostMonitorView = monitor
        }

        if (floatingView == null) {
            attachFloatingButton()
        }
    }

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun attachFloatingButton() {
        val view = LayoutInflater.from(this).inflate(R.layout.floating_button_layout, null)
        floatingCircle = view.findViewById(R.id.floatingCircle)
        floatingStateText = view.findViewById(R.id.floatingStateText)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.floatingX
            y = prefs.floatingY
        }

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop

        view.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isDragging = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isDragging = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                            isDragging = true
                        }
                        if (isDragging) {
                            val (maxX, maxY) = getScreenBounds()
                            params.x = (initialX + dx).coerceIn(0, (maxX - v.width).coerceAtLeast(0))
                            params.y = (initialY + dy).coerceIn(0, (maxY - v.height).coerceAtLeast(0))
                            try {
                                windowManager.updateViewLayout(v, params)
                            } catch (_: IllegalArgumentException) {
                            }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (isDragging) {
                            prefs.floatingX = params.x
                            prefs.floatingY = params.y
                        } else {
                            setProtectionArmed(!prefs.isProtectionEnabled)
                        }
                        return true
                    }
                }
                return false
            }
        })

        // Added AFTER GhostMonitorView so the floating toggle stays above the touch shield.
        windowManager.addView(view, params)
        floatingView = view
        floatingLayoutParams = params
        updateFloatingButtonAppearance(prefs.isProtectionEnabled)
    }

    private fun getScreenBounds(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            @Suppress("DEPRECATION")
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getMetrics(metrics)
            metrics.widthPixels to metrics.heightPixels
        }
    }

    private fun setProtectionArmed(armed: Boolean) {
        if (armed && !hasMandatoryPermissions()) {
            prefs.isProtectionEnabled = false
            updateFloatingButtonAppearance(false)
            ghostMonitorView?.setArmed(false)
            updateNotification(false)
            return
        }
        prefs.isProtectionEnabled = armed
        updateFloatingButtonAppearance(armed)
        ghostMonitorView?.setArmed(armed)
        updateNotification(armed)
    }

    private fun updateFloatingButtonAppearance(armed: Boolean) {
        floatingCircle?.setBackgroundResource(
            if (armed) R.drawable.bg_floating_on else R.drawable.bg_floating_off
        )
        floatingStateText?.setText(
            if (armed) R.string.floating_label_on else R.string.floating_label_off
        )
    }

    private fun performLockAndWakeCycle() {
        val adminComponent = GhostDeviceAdminReceiver.getComponentName(this)
        if (!devicePolicyManager.isAdminActive(adminComponent)) {
            prefs.lastEventOutcome = "Lock failed (Device Admin inactive)"
            return
        }

        try {
            devicePolicyManager.lockNow()
            handler.removeCallbacks(wakeRunnable)
            handler.postDelayed(wakeRunnable, prefs.wakeDelayMs)
        } catch (e: SecurityException) {
            prefs.lastEventOutcome = "Lock blocked by policy"
        }
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        try {
            if (!powerManager.isInteractive) {
                val wakeLock = powerManager.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "GhostTouchGuard:RecoveryWakeLock"
                )
                wakeLock.acquire(3000L)
            }
            val keyguardLocked = keyguardManager.isKeyguardLocked
            prefs.lastEventOutcome = if (keyguardLocked) {
                "Locked & woke (keyguard active)"
            } else {
                "Locked & woke screen"
            }
        } catch (_: Exception) {
            prefs.lastEventOutcome = "Locked screen (wake skipped)"
        }
    }

    private fun detachOverlays() {
        ghostMonitorView?.let { monitor ->
            monitor.release()
            if (monitor.isAttachedToWindow) {
                try {
                    windowManager.removeView(monitor)
                } catch (_: IllegalArgumentException) {
                }
            }
        }
        ghostMonitorView = null

        floatingView?.let { button ->
            if (button.isAttachedToWindow) {
                try {
                    windowManager.removeView(button)
                } catch (_: IllegalArgumentException) {
                }
            }
        }
        floatingView = null
        floatingLayoutParams = null
        floatingCircle = null
        floatingStateText = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun updateNotification(armed: Boolean) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(armed))
    }

    private fun buildNotification(armed: Boolean): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            100,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleIntent = Intent(this, FloatingService::class.java).apply {
            action = ACTION_TOGGLE_PROTECTION
        }
        val togglePendingIntent = PendingIntent.getService(
            this,
            101,
            toggleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val contentText = getString(
            if (armed) R.string.notification_status_on else R.string.notification_status_off
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_shield)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(contentText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openPendingIntent)
            .addAction(
                R.drawable.ic_shield,
                getString(R.string.notification_action_toggle),
                togglePendingIntent
            )
            .build()
    }

    companion object {
        const val CHANNEL_ID = "ghost_touch_guard_channel"
        const val NOTIFICATION_ID = 4101

        const val ACTION_START_SERVICE = "com.ghosttouchguard.app.ACTION_START_SERVICE"
        const val ACTION_STOP_SERVICE = "com.ghosttouchguard.app.ACTION_STOP_SERVICE"
        const val ACTION_TOGGLE_PROTECTION = "com.ghosttouchguard.app.ACTION_TOGGLE_PROTECTION"
        const val ACTION_SET_PROTECTION = "com.ghosttouchguard.app.ACTION_SET_PROTECTION"
        const val ACTION_REPORT_POINTER_SAMPLE =
            "com.ghosttouchguard.app.ACTION_REPORT_POINTER_SAMPLE"

        const val EXTRA_ARMED = "extra_armed"
        const val EXTRA_POINTER_COUNT = "extra_pointer_count"
    }
}
