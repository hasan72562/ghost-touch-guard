package com.ghosttouchguard.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: GuardPreferences
    private lateinit var devicePolicyManager: DevicePolicyManager

    // Permission views
    private lateinit var tvOverlayStatus: TextView
    private lateinit var btnGrantOverlay: Button
    private lateinit var tvAdminStatus: TextView
    private lateinit var btnGrantAdmin: Button
    private lateinit var tvNotifStatus: TextView
    private lateinit var btnGrantNotif: Button
    private lateinit var tvFgsStatus: TextView
    private lateinit var btnFgsInfo: Button

    // Protection & Status views
    private lateinit var switchProtection: SwitchCompat
    private lateinit var tvProtectionHint: TextView
    private lateinit var btnStartFloatingService: Button
    private lateinit var btnStopFloatingService: Button
    private lateinit var tvStatusState: TextView
    private lateinit var tvLastEventTime: TextView
    private lateinit var tvLastOutcome: TextView
    private lateinit var tvTriggerCount: TextView
    private lateinit var btnResetCounter: Button

    // Settings views
    private lateinit var tvTouchesValue: TextView
    private lateinit var seekTouches: SeekBar
    private lateinit var tvPersistenceValue: TextView
    private lateinit var seekPersistence: SeekBar
    private lateinit var tvWakeDelayValue: TextView
    private lateinit var seekWakeDelay: SeekBar

    // Test pad & Xiaomi settings
    private lateinit var touchTestPad: FrameLayout
    private lateinit var tvTestPadStatus: TextView
    private lateinit var btnOpenXiaomiSettings: Button

    private var suppressSwitchCallback = false

    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            refreshUi()
        }

    private val deviceAdminLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            refreshUi()
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            refreshUi()
        }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        runOnUiThread { refreshStatusAndSwitch() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = GuardPreferences(this)
        devicePolicyManager =
            getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

        bindViews()
        setupPermissionButtons()
        setupProtectionControls()
        setupSettingsSliders()
        setupTestPad()
        setupXiaomiHelpButton()
    }

    override fun onResume() {
        super.onResume()
        prefs.registerListener(prefListener)
        refreshUi()
    }

    override fun onPause() {
        prefs.unregisterListener(prefListener)
        super.onPause()
    }

    private fun bindViews() {
        tvOverlayStatus = findViewById(R.id.tvOverlayStatus)
        btnGrantOverlay = findViewById(R.id.btnGrantOverlay)
        tvAdminStatus = findViewById(R.id.tvAdminStatus)
        btnGrantAdmin = findViewById(R.id.btnGrantAdmin)
        tvNotifStatus = findViewById(R.id.tvNotifStatus)
        btnGrantNotif = findViewById(R.id.btnGrantNotif)
        tvFgsStatus = findViewById(R.id.tvFgsStatus)
        btnFgsInfo = findViewById(R.id.btnFgsInfo)

        switchProtection = findViewById(R.id.switchProtection)
        tvProtectionHint = findViewById(R.id.tvProtectionHint)
        btnStartFloatingService = findViewById(R.id.btnStartFloatingService)
        btnStopFloatingService = findViewById(R.id.btnStopFloatingService)
        tvStatusState = findViewById(R.id.tvStatusState)
        tvLastEventTime = findViewById(R.id.tvLastEventTime)
        tvLastOutcome = findViewById(R.id.tvLastOutcome)
        tvTriggerCount = findViewById(R.id.tvTriggerCount)
        btnResetCounter = findViewById(R.id.btnResetCounter)

        tvTouchesValue = findViewById(R.id.tvTouchesValue)
        seekTouches = findViewById(R.id.seekTouches)
        tvPersistenceValue = findViewById(R.id.tvPersistenceValue)
        seekPersistence = findViewById(R.id.seekPersistence)
        tvWakeDelayValue = findViewById(R.id.tvWakeDelayValue)
        seekWakeDelay = findViewById(R.id.seekWakeDelay)

        touchTestPad = findViewById(R.id.touchTestPad)
        tvTestPadStatus = findViewById(R.id.tvTestPadStatus)
        btnOpenXiaomiSettings = findViewById(R.id.btnOpenXiaomiSettings)
    }

    private fun setupPermissionButtons() {
        // (a) Draw over other apps
        btnGrantOverlay.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        }

        // (b) Device Admin
        btnGrantAdmin.setOnClickListener {
            val component = GhostDeviceAdminReceiver.getComponentName(this)
            if (devicePolicyManager.isAdminActive(component)) {
                Toast.makeText(this, "Device Admin is already active.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component)
                putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    getString(R.string.device_admin_description)
                )
            }
            deviceAdminLauncher.launch(intent)
        }

        // (c) Notification permission (Android 13+)
        btnGrantNotif.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val granted = ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
                if (!granted) {
                    if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                } else {
                    openAppDetailsSettings()
                }
            } else {
                openAppDetailsSettings()
            }
        }

        // (d) Foreground service permission / HyperOS background info
        btnFgsInfo.setOnClickListener {
            openAppDetailsSettings()
        }
    }

    private fun setupProtectionControls() {
        switchProtection.setOnCheckedChangeListener { _, isChecked ->
            if (suppressSwitchCallback) return@setOnCheckedChangeListener

            if (!areCorePermissionsGranted()) {
                suppressSwitchCallback = true
                switchProtection.isChecked = false
                suppressSwitchCallback = false
                Toast.makeText(
                    this,
                    "Grant Overlay and Device Admin permissions first.",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnCheckedChangeListener
            }

            sendServiceAction(FloatingService.ACTION_SET_PROTECTION) {
                putExtra(FloatingService.EXTRA_ARMED, isChecked)
            }
        }

        btnStartFloatingService.setOnClickListener {
            if (!areCorePermissionsGranted()) {
                Toast.makeText(
                    this,
                    "Please grant (a) Overlay and (b) Device Admin permissions first.",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            sendServiceAction(FloatingService.ACTION_START_SERVICE)
        }

        btnStopFloatingService.setOnClickListener {
            if (prefs.isServiceRunning) {
                sendServiceAction(FloatingService.ACTION_STOP_SERVICE)
            } else {
                prefs.isProtectionEnabled = false
                prefs.guardStateLabel = "OFF"
                refreshUi()
            }
        }

        btnResetCounter.setOnClickListener {
            prefs.resetCounter()
            refreshStatusAndSwitch()
        }
    }

    private fun setupSettingsSliders() {
        // Touches needed: 2..5 (seek 0..3)
        seekTouches.progress = (prefs.triggerTouchCount - 2).coerceIn(0, 3)
        tvTouchesValue.text = "${prefs.triggerTouchCount} touches"
        seekTouches.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val touches = progress + 2
                tvTouchesValue.text = "$touches touches"
                if (fromUser) prefs.triggerTouchCount = touches
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        // Persistence time before lock: 1.0s..5.0s in 0.5s steps (seek 0..8, default 2 -> 2.0s)
        seekPersistence.progress =
            ((prefs.persistenceTimeMs - 1000L) / 500L).toInt().coerceIn(0, 8)
        tvPersistenceValue.text = formatSeconds(prefs.persistenceTimeMs)
        seekPersistence.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val ms = 1000L + progress * 500L
                tvPersistenceValue.text = formatSeconds(ms)
                if (fromUser) prefs.persistenceTimeMs = ms
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        // Wake delay: 0.5s..3.0s in 0.5s steps (seek 0..5, default 1 -> 1.0s)
        seekWakeDelay.progress =
            ((prefs.wakeDelayMs - 500L) / 500L).toInt().coerceIn(0, 5)
        tvWakeDelayValue.text = formatSeconds(prefs.wakeDelayMs)
        seekWakeDelay.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val ms = 500L + progress * 500L
                tvWakeDelayValue.text = formatSeconds(ms)
                if (fromUser) prefs.wakeDelayMs = ms
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTestPad() {
        touchTestPad.setOnTouchListener { _, event ->
            val pointers = when (event.actionMasked) {
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> 0
                MotionEvent.ACTION_POINTER_UP -> (event.pointerCount - 1).coerceAtLeast(0)
                else -> event.pointerCount
            }

            tvTestPadStatus.text = if (pointers == 0) {
                getString(R.string.test_pad_idle)
            } else {
                "Active touches detected: $pointers (threshold: ${prefs.triggerTouchCount})"
            }

            if (prefs.isServiceRunning && prefs.isProtectionEnabled) {
                val report = Intent(this, FloatingService::class.java).apply {
                    action = FloatingService.ACTION_REPORT_POINTER_SAMPLE
                    putExtra(FloatingService.EXTRA_POINTER_COUNT, pointers)
                }
                startService(report)
            }
            true
        }
    }

    private fun setupXiaomiHelpButton() {
        btnOpenXiaomiSettings.setOnClickListener {
            openAppDetailsSettings()
        }
    }

    private fun sendServiceAction(action: String, extras: (Intent.() -> Unit)? = null) {
        val intent = Intent(this, FloatingService::class.java).apply {
            this.action = action
            extras?.invoke(this)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun openAppDetailsSettings() {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun isOverlayGranted(): Boolean = Settings.canDrawOverlays(this)

    private fun isAdminGranted(): Boolean =
        devicePolicyManager.isAdminActive(GhostDeviceAdminReceiver.getComponentName(this))

    private fun isNotificationGranted(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            NotificationManagerCompat.from(this).areNotificationsEnabled()
        }
    }

    private fun isForegroundServicePermissionGranted(): Boolean {
        val fgsBasic = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.FOREGROUND_SERVICE
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        val fgsSpecialUse = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.FOREGROUND_SERVICE_SPECIAL_USE
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        return fgsBasic && fgsSpecialUse
    }

    private fun areCorePermissionsGranted(): Boolean {
        return isOverlayGranted() && isAdminGranted()
    }

    private fun refreshUi() {
        val overlayOk = isOverlayGranted()
        val adminOk = isAdminGranted()
        val notifOk = isNotificationGranted()
        val fgsOk = isForegroundServicePermissionGranted()

        updatePermissionRow(tvOverlayStatus, btnGrantOverlay, overlayOk)
        updatePermissionRow(tvAdminStatus, btnGrantAdmin, adminOk)
        updatePermissionRow(tvNotifStatus, btnGrantNotif, notifOk)

        tvFgsStatus.setText(if (fgsOk) R.string.status_granted else R.string.status_missing)
        tvFgsStatus.setTextColor(
            ContextCompat.getColor(
                this,
                if (fgsOk) R.color.status_granted else R.color.status_missing
            )
        )

        val coreReady = overlayOk && adminOk
        switchProtection.isEnabled = coreReady
        btnStartFloatingService.isEnabled = coreReady
        btnStartFloatingService.alpha = if (coreReady) 1f else 0.5f

        tvProtectionHint.setText(
            if (coreReady) R.string.toggle_protection_hint_ready
            else R.string.toggle_protection_hint_locked
        )

        if (!coreReady && prefs.isProtectionEnabled) {
            prefs.isProtectionEnabled = false
            prefs.guardStateLabel = "OFF"
        }

        refreshStatusAndSwitch()
    }

    private fun updatePermissionRow(statusView: TextView, button: Button, granted: Boolean) {
        statusView.setText(if (granted) R.string.status_granted else R.string.status_missing)
        statusView.setTextColor(
            ContextCompat.getColor(
                this,
                if (granted) R.color.status_granted else R.color.status_missing
            )
        )
        button.setText(if (granted) R.string.btn_granted else R.string.btn_grant)
        button.backgroundTintList = ContextCompat.getColorStateList(
            this,
            if (granted) R.color.status_granted else R.color.accent_blue
        )
    }

    private fun refreshStatusAndSwitch() {
        suppressSwitchCallback = true
        switchProtection.isChecked = prefs.isProtectionEnabled
        suppressSwitchCallback = false

        tvStatusState.text = prefs.guardStateLabel
        tvStatusState.setTextColor(
            ContextCompat.getColor(
                this,
                if (prefs.isProtectionEnabled) R.color.guard_red else R.color.text_primary
            )
        )

        val ts = prefs.lastEventTimestamp
        tvLastEventTime.text = if (ts == 0L) {
            "Never"
        } else {
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(ts))
        }

        tvLastOutcome.text = prefs.lastEventOutcome
        tvTriggerCount.text = prefs.triggerCount.toString()
    }

    private fun formatSeconds(ms: Long): String {
        return String.format(Locale.US, "%.1f s", ms / 1000.0)
    }
}
