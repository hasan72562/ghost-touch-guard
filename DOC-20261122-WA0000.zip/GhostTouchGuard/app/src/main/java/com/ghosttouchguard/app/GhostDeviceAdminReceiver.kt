package com.ghosttouchguard.app

import android.app.admin.DeviceAdminReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.Toast

class GhostDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Toast.makeText(
            context,
            "GhostTouchGuard Device Admin enabled",
            Toast.LENGTH_SHORT
        ).show()
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        return "Disabling Device Admin prevents GhostTouchGuard from locking the screen when ghost touches persist."
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        val prefs = GuardPreferences(context)
        if (prefs.isProtectionEnabled) {
            prefs.isProtectionEnabled = false
            prefs.guardStateLabel = "OFF (Admin removed)"
        }
        Toast.makeText(
            context,
            "GhostTouchGuard Device Admin disabled — protection disarmed",
            Toast.LENGTH_SHORT
        ).show()
    }

    companion object {
        fun getComponentName(context: Context): ComponentName {
            return ComponentName(context.applicationContext, GhostDeviceAdminReceiver::class.java)
        }
    }
}
