package com.ghosttouchguard.app

import android.content.Context
import android.content.SharedPreferences

class GuardPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var isProtectionEnabled: Boolean
        get() = prefs.getBoolean(KEY_PROTECTION_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_PROTECTION_ENABLED, value).apply()

    var isServiceRunning: Boolean
        get() = prefs.getBoolean(KEY_SERVICE_RUNNING, false)
        set(value) = prefs.edit().putBoolean(KEY_SERVICE_RUNNING, value).apply()

    var guardStateLabel: String
        get() = prefs.getString(KEY_GUARD_STATE_LABEL, "OFF") ?: "OFF"
        set(value) = prefs.edit().putString(KEY_GUARD_STATE_LABEL, value).apply()

    var triggerTouchCount: Int
        get() = prefs.getInt(KEY_TRIGGER_TOUCH_COUNT, DEFAULT_TRIGGER_TOUCHES).coerceIn(2, 5)
        set(value) = prefs.edit().putInt(KEY_TRIGGER_TOUCH_COUNT, value.coerceIn(2, 5)).apply()

    var persistenceTimeMs: Long
        get() = prefs.getLong(KEY_PERSISTENCE_TIME_MS, DEFAULT_PERSISTENCE_MS).coerceIn(1000L, 5000L)
        set(value) = prefs.edit().putLong(KEY_PERSISTENCE_TIME_MS, value.coerceIn(1000L, 5000L)).apply()

    var wakeDelayMs: Long
        get() = prefs.getLong(KEY_WAKE_DELAY_MS, DEFAULT_WAKE_DELAY_MS).coerceIn(500L, 3000L)
        set(value) = prefs.edit().putLong(KEY_WAKE_DELAY_MS, value.coerceIn(500L, 3000L)).apply()

    var lastEventTimestamp: Long
        get() = prefs.getLong(KEY_LAST_EVENT_TS, 0L)
        private set(value) = prefs.edit().putLong(KEY_LAST_EVENT_TS, value).apply()

    var lastEventOutcome: String
        get() = prefs.getString(KEY_LAST_EVENT_OUTCOME, "None") ?: "None"
        set(value) = prefs.edit().putString(KEY_LAST_EVENT_OUTCOME, value).apply()

    var triggerCount: Int
        get() = prefs.getInt(KEY_TRIGGER_COUNT, 0)
        private set(value) = prefs.edit().putInt(KEY_TRIGGER_COUNT, value).apply()

    var floatingX: Int
        get() = prefs.getInt(KEY_FLOATING_X, 24)
        set(value) = prefs.edit().putInt(KEY_FLOATING_X, value).apply()

    var floatingY: Int
        get() = prefs.getInt(KEY_FLOATING_Y, 360)
        set(value) = prefs.edit().putInt(KEY_FLOATING_Y, value).apply()

    fun recordGhostEvent(outcome: String) {
        val nextCount = triggerCount + 1
        prefs.edit()
            .putLong(KEY_LAST_EVENT_TS, System.currentTimeMillis())
            .putString(KEY_LAST_EVENT_OUTCOME, outcome)
            .putInt(KEY_TRIGGER_COUNT, nextCount)
            .apply()
    }

    fun resetCounter() {
        prefs.edit()
            .putInt(KEY_TRIGGER_COUNT, 0)
            .putLong(KEY_LAST_EVENT_TS, 0L)
            .putString(KEY_LAST_EVENT_OUTCOME, "None")
            .apply()
    }

    fun registerListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregisterListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
    }

    companion object {
        private const val PREFS_NAME = "ghost_touch_guard_prefs"

        private const val KEY_PROTECTION_ENABLED = "protection_enabled"
        private const val KEY_SERVICE_RUNNING = "service_running"
        private const val KEY_GUARD_STATE_LABEL = "guard_state_label"
        private const val KEY_TRIGGER_TOUCH_COUNT = "trigger_touch_count"
        private const val KEY_PERSISTENCE_TIME_MS = "persistence_time_ms"
        private const val KEY_WAKE_DELAY_MS = "wake_delay_ms"
        private const val KEY_LAST_EVENT_TS = "last_event_ts"
        private const val KEY_LAST_EVENT_OUTCOME = "last_event_outcome"
        private const val KEY_TRIGGER_COUNT = "trigger_count"
        private const val KEY_FLOATING_X = "floating_x"
        private const val KEY_FLOATING_Y = "floating_y"

        const val DEFAULT_TRIGGER_TOUCHES = 2
        const val DEFAULT_PERSISTENCE_MS = 2000L
        const val DEFAULT_WAKE_DELAY_MS = 1000L
        const val RESET_BLOCK_DURATION_MS = 800L
        const val LOCK_WAKE_COOLDOWN_MS = 6000L
    }
}
