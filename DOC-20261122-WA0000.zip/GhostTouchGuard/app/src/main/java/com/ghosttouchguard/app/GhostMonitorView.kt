package com.ghosttouchguard.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Full-screen transparent overlay that monitors touch activity across the entire screen.
 *
 * Normally stays in pass-through mode (FLAG_NOT_TOUCHABLE | FLAG_WATCH_OUTSIDE_TOUCH) so
 * single touches pass cleanly through to the app underneath.
 *
 * When ghost touches are detected (2+ simultaneous pointers, or rapid phantom touch bursts
 * verified via a brief probe), it switches to blocking mode for ~800 ms, vibrates, displays
 * "Resetting touch…", and consumes all touch input to clear the stuck touch stream.
 *
 * If ghost touches persist for [GuardPreferences.persistenceTimeMs] (default 2000 ms) after
 * the reset finishes, [onPersistenceEscalation] is invoked to lock and wake the screen,
 * followed by a 6-second cooldown.
 */
@SuppressLint("ViewConstructor")
class GhostMonitorView(
    context: Context,
    private val windowManager: WindowManager,
    private val prefs: GuardPreferences,
    private val onPersistenceEscalation: () -> Unit
) : FrameLayout(context) {

    enum class GuardState {
        DISARMED,
        MONITORING,
        PROBING,
        RESETTING,
        POST_RESET_WATCH,
        COOLDOWN
    }

    private val handler = Handler(Looper.getMainLooper())
    private val resetBanner: LinearLayout
    private val resetBannerSubtitle: TextView

    var state: GuardState = GuardState.DISARMED
        private set

    private val outsideTapTimestamps = ArrayDeque<Long>()
    private var postResetStartElapsed = 0L
    private var postResetTouchHits = 0
    private var activeExternalPointers = 0

    val overlayLayoutParams: WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        PASS_THROUGH_FLAGS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 0
        y = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private val finishProbeRunnable = Runnable {
        if (state == GuardState.PROBING) {
            enterMonitoringState()
        }
    }

    private val finishResetRunnable = Runnable {
        if (state == GuardState.RESETTING) {
            beginPostResetWatch()
        }
    }

    private val finishPostResetWatchRunnable = Runnable {
        if (state == GuardState.POST_RESET_WATCH) {
            if (activeExternalPointers >= prefs.triggerTouchCount) {
                escalateToLockAndWake()
            } else {
                enterMonitoringState()
            }
        }
    }

    private val finishCooldownRunnable = Runnable {
        if (state == GuardState.COOLDOWN) {
            if (prefs.isProtectionEnabled) {
                enterMonitoringState()
            } else {
                setArmed(false)
            }
        }
    }

    init {
        LayoutInflater.from(context).inflate(R.layout.ghost_monitor_overlay, this, true)
        resetBanner = findViewById(R.id.resetBanner)
        resetBannerSubtitle = findViewById(R.id.resetBannerSubtitle)
        visibility = View.GONE
    }

    fun setArmed(armed: Boolean) {
        cancelPendingRunnables()
        outsideTapTimestamps.clear()
        activeExternalPointers = 0
        if (armed) {
            visibility = View.VISIBLE
            enterMonitoringState()
        } else {
            state = GuardState.DISARMED
            resetBanner.visibility = View.GONE
            applyWindowFlags(PASS_THROUGH_FLAGS)
            visibility = View.GONE
            prefs.guardStateLabel = "OFF"
        }
    }

    fun release() {
        cancelPendingRunnables()
    }

    /**
     * Allows the in-app multi-touch test pad (or direct multi-touch capture) to report real
     * simultaneous pointer counts while the overlay is in pass-through mode.
     */
    fun handlePointerSample(pointerCount: Int) {
        activeExternalPointers = pointerCount
        if (!prefs.isProtectionEnabled) return

        when (state) {
            GuardState.MONITORING, GuardState.PROBING -> {
                if (pointerCount >= prefs.triggerTouchCount) {
                    triggerDigitizerReset()
                }
            }
            GuardState.POST_RESET_WATCH -> {
                if (pointerCount >= prefs.triggerTouchCount) {
                    postResetTouchHits++
                    val elapsedAfterReset = SystemClock.elapsedRealtime() - postResetStartElapsed
                    if (elapsedAfterReset >= prefs.persistenceTimeMs) {
                        escalateToLockAndWake()
                    }
                }
            }
            GuardState.RESETTING, GuardState.COOLDOWN, GuardState.DISARMED -> Unit
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        return handleMotionEvent(ev)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        return handleMotionEvent(event)
    }

    private fun handleMotionEvent(event: MotionEvent): Boolean {
        val action = event.actionMasked

        if (state == GuardState.DISARMED) {
            return false
        }

        if (state == GuardState.COOLDOWN) {
            return false
        }

        // During the 800 ms digitizer reset, block and consume ALL touches unconditionally.
        if (state == GuardState.RESETTING) {
            return true
        }

        // Pass-through mode receives ACTION_OUTSIDE when touches occur on apps underneath.
        if (action == MotionEvent.ACTION_OUTSIDE) {
            handleOutsideTouch()
            return false
        }

        // Direct multi-touch inspection (during PROBING or active touch interception).
        val pointers = event.pointerCount
        if (pointers >= prefs.triggerTouchCount) {
            when (state) {
                GuardState.MONITORING, GuardState.PROBING -> {
                    triggerDigitizerReset()
                    return true
                }
                GuardState.POST_RESET_WATCH -> {
                    postResetTouchHits++
                    val elapsedAfterReset = SystemClock.elapsedRealtime() - postResetStartElapsed
                    if (elapsedAfterReset >= prefs.persistenceTimeMs) {
                        escalateToLockAndWake()
                    }
                    return true
                }
                else -> Unit
            }
        }

        return state == GuardState.PROBING
    }

    private fun handleOutsideTouch() {
        val now = SystemClock.elapsedRealtime()

        if (state == GuardState.POST_RESET_WATCH) {
            postResetTouchHits++
            val elapsedAfterReset = now - postResetStartElapsed
            // If touches keep arriving up to/past the persistence threshold after reset, escalate.
            if (elapsedAfterReset >= prefs.persistenceTimeMs && postResetTouchHits >= 2) {
                escalateToLockAndWake()
            }
            return
        }

        if (state != GuardState.MONITORING) return

        outsideTapTimestamps.addLast(now)
        while (outsideTapTimestamps.isNotEmpty() && now - outsideTapTimestamps.first() > BURST_WINDOW_MS) {
            outsideTapTimestamps.removeFirst()
        }

        // When >= 3 rapid phantom touch-down events occur within 320 ms, briefly switch to
        // PROBING (140 ms) to inspect full MotionEvent.pointerCount directly from the digitizer.
        if (outsideTapTimestamps.size >= BURST_PROBE_THRESHOLD) {
            outsideTapTimestamps.clear()
            enterProbingWindow()
        }
    }

    private fun enterMonitoringState() {
        cancelPendingRunnables()
        state = GuardState.MONITORING
        resetBanner.visibility = View.GONE
        applyWindowFlags(PASS_THROUGH_FLAGS)
        prefs.guardStateLabel = "Monitoring (ON)"
    }

    private fun enterProbingWindow() {
        state = GuardState.PROBING
        applyWindowFlags(INTERCEPT_FLAGS)
        handler.removeCallbacks(finishProbeRunnable)
        handler.postDelayed(finishProbeRunnable, PROBE_DURATION_MS)
    }

    private fun triggerDigitizerReset() {
        cancelPendingRunnables()
        outsideTapTimestamps.clear()
        state = GuardState.RESETTING

        applyWindowFlags(INTERCEPT_FLAGS)
        resetBannerSubtitle.text = context.getString(R.string.resetting_touch_sub)
        resetBanner.visibility = View.VISIBLE
        prefs.guardStateLabel = "Resetting touch…"
        prefs.recordGhostEvent("Touch reset (800 ms)")

        vibrateResetPulse()

        handler.postDelayed(finishResetRunnable, GuardPreferences.RESET_BLOCK_DURATION_MS)
    }

    private fun beginPostResetWatch() {
        state = GuardState.POST_RESET_WATCH
        resetBanner.visibility = View.GONE
        applyWindowFlags(PASS_THROUGH_FLAGS)
        postResetStartElapsed = SystemClock.elapsedRealtime()
        postResetTouchHits = if (activeExternalPointers >= prefs.triggerTouchCount) 1 else 0
        prefs.guardStateLabel = "Post-reset watch"

        val totalWatchWindow = prefs.persistenceTimeMs + POST_RESET_GRACE_MS
        handler.removeCallbacks(finishPostResetWatchRunnable)
        handler.postDelayed(finishPostResetWatchRunnable, totalWatchWindow)
    }

    private fun escalateToLockAndWake() {
        cancelPendingRunnables()
        state = GuardState.COOLDOWN
        resetBanner.visibility = View.GONE
        applyWindowFlags(PASS_THROUGH_FLAGS)
        prefs.guardStateLabel = "Cooldown (6s)"
        prefs.recordGhostEvent("Lock & wake recovery")

        onPersistenceEscalation()

        handler.postDelayed(finishCooldownRunnable, GuardPreferences.LOCK_WAKE_COOLDOWN_MS)
    }

    private fun applyWindowFlags(flags: Int) {
        if (overlayLayoutParams.flags == flags) return
        overlayLayoutParams.flags = flags
        if (isAttachedToWindow) {
            try {
                windowManager.updateViewLayout(this, overlayLayoutParams)
            } catch (_: IllegalArgumentException) {
                // View was detached concurrently; safe to ignore.
            }
        }
    }

    private fun cancelPendingRunnables() {
        handler.removeCallbacks(finishProbeRunnable)
        handler.removeCallbacks(finishResetRunnable)
        handler.removeCallbacks(finishPostResetWatchRunnable)
        handler.removeCallbacks(finishCooldownRunnable)
    }

    @Suppress("DEPRECATION")
    private fun vibrateResetPulse() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager =
                    context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(65L, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(
                        VibrationEffect.createOneShot(65L, VibrationEffect.DEFAULT_AMPLITUDE)
                    )
                } else {
                    vibrator?.vibrate(65L)
                }
            }
        } catch (_: SecurityException) {
            // Vibration unavailable; proceed with touch block.
        }
    }

    companion object {
        private const val PASS_THROUGH_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        private const val INTERCEPT_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        private const val BURST_WINDOW_MS = 320L
        private const val BURST_PROBE_THRESHOLD = 3
        private const val PROBE_DURATION_MS = 140L
        private const val POST_RESET_GRACE_MS = 1000L
    }
}
